<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'agenda_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_URL', '/Agenda-de-Pacientes');

// Caminho base para as views e controllers
define('APP_ROOT', dirname(__DIR__));
